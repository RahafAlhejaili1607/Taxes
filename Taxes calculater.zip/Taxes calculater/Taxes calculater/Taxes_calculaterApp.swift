//
//  Taxes_calculaterApp.swift
//  Taxes calculater
//
//  Created by Rahaf Alhejaili on 14/06/1444 AH.
//

import SwiftUI

@main
struct Taxes_calculaterApp: App {
    var body: some Scene {
        WindowGroup {
            Segmentedcontroll()

        }
    }
}
